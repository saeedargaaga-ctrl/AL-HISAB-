
import React, { useState, useEffect } from 'react';
import { 
  Clock as ClockIcon, 
  FileText, 
  MessageSquare, 
  Search as SearchIcon, 
  BookOpen, 
  CheckSquare, 
  Lightbulb, 
  Settings as SettingsIcon,
  Home,
  User as UserIcon,
  ChevronLeft,
  Share2,
  Sparkles,
  Target
} from 'lucide-react';
import { View, Note, Task, Book, Idea, Post, Language, ThemeColor } from './types';
import { Clock } from './components/Clock';
import { Notes } from './components/Notes';
import { AIAssistant } from './components/AI';
import { Search } from './components/Search';
import { Library } from './components/Library';
import { Tasks } from './components/Tasks';
import { Innovation } from './components/Innovation';
import { Community } from './components/Community';
import { Summary } from './components/Summary';
import { Settings } from './components/Settings';
import { LanguagePicker } from './components/LanguagePicker';
import { translations } from './services/translations';

const App: React.FC = () => {
  const [view, setView] = useState<View>('onboarding');
  const [language, setLanguage] = useState<Language>('ar');
  const [themeColor, setThemeColor] = useState<ThemeColor>('indigo');
  const [notes, setNotes] = useState<Note[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [books, setBooks] = useState<Book[]>([]);
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isTransitioning, setIsTransitioning] = useState(false);
  
  const t = translations[language];
  const isRTL = language === 'ar' || language === 'ur';

  useEffect(() => {
    const saved = localStorage.getItem('hisab_data_vfinal_v4');
    if (saved) {
      const data = JSON.parse(saved);
      setNotes(data.notes || []);
      setTasks(data.tasks || []);
      setBooks(data.books || []);
      setIdeas(data.ideas || []);
      setPosts(data.posts || []);
      if (data.language) setLanguage(data.language);
      if (data.themeColor) setThemeColor(data.themeColor);
    }
  }, []);

  useEffect(() => {
    // تحديث اتجاه المستند فوراً عند تغيير اللغة
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    localStorage.setItem('hisab_data_vfinal_v4', JSON.stringify({ notes, tasks, books, ideas, posts, language, themeColor }));
  }, [language, isRTL, notes, tasks, books, ideas, posts, themeColor]);

  const changeLanguage = (lang: Language) => {
    setIsTransitioning(true);
    // تغيير الاتجاه واللغة فوراً للمتصفح
    document.documentElement.dir = (lang === 'ar' || lang === 'ur') ? 'rtl' : 'ltr';
    setTimeout(() => {
      setLanguage(lang);
      setIsTransitioning(false);
    }, 300);
  };

  const changeView = (v: View) => {
    setIsTransitioning(true);
    setTimeout(() => {
      setView(v);
      setIsTransitioning(false);
    }, 300);
  };

  const renderView = () => {
    switch (view) {
      case 'home': return <HomeView setView={changeView} language={language} t={t} />;
      case 'clock': return <Clock t={t} />;
      case 'notes': return <Notes t={t} notes={notes} language={language} onSave={n => {
        setNotes(prev => {
          const exists = prev.find(p => p.id === n.id);
          if (exists) return prev.map(p => p.id === n.id ? n : p);
          return [n, ...prev];
        });
      }} onDelete={id => setNotes(prev => prev.filter(p => p.id !== id))} />;
      case 'ai': return <AIAssistant t={t} language={language} />;
      case 'search': return <Search t={t} language={language} />;
      case 'library': return (
        <Library 
          t={t}
          books={books} 
          onAddBook={b => setBooks([b, ...books])} 
          onUpdateBook={updatedBook => setBooks(books.map(b => b.id === updatedBook.id ? updatedBook : b))}
        />
      );
      case 'tasks': return <Tasks t={t} tasks={tasks} onUpdate={setTasks} />;
      case 'innovation': return <Innovation t={t} ideas={ideas} language={language} onUpdate={setIdeas} />;
      case 'community': return <Community t={t} posts={posts} language={language} onPublish={p => setPosts([p, ...posts])} onDelete={id => setPosts(posts.filter(p => p.id !== id))} />;
      case 'khulas': return <Summary t={t} notes={notes} tasks={tasks} books={books} ideas={ideas} />;
      case 'settings': return (
        <Settings 
          language={language} 
          onLanguageChange={changeLanguage} 
          themeColor={themeColor} 
          onThemeChange={setThemeColor} 
          onLogout={() => changeView('onboarding')}
        />
      );
      default: return <HomeView setView={changeView} language={language} t={t} />;
    }
  };

  const themeColors = {
    indigo: 'from-indigo-600 via-purple-600 to-pink-500 shadow-purple-200 text-indigo-700',
    rose: 'from-rose-600 via-pink-600 to-rose-400 shadow-rose-200 text-rose-700',
    emerald: 'from-emerald-600 via-teal-600 to-green-400 shadow-emerald-200 text-emerald-700',
    amber: 'from-amber-500 via-orange-500 to-yellow-400 shadow-amber-200 text-amber-700',
    blue: 'from-blue-600 via-sky-600 to-cyan-400 shadow-blue-200 text-blue-700',
    purple: 'from-purple-600 via-violet-600 to-indigo-500 shadow-purple-200 text-purple-700',
    slate: 'from-slate-700 via-slate-800 to-slate-900 shadow-slate-200 text-slate-800'
  };

  if (view === 'onboarding') {
    return <Onboarding onEnter={() => changeView('home')} language={language} t={t} onLanguageChange={changeLanguage} />;
  }

  return (
    <div className={`min-h-screen flex flex-col bg-slate-50 transition-all duration-700 ${isRTL ? 'font-arabic' : 'font-sans'}`}>
      <header className="glass sticky top-0 z-50 border-b border-slate-200/50 p-4 md:p-6 shadow-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div 
            onClick={() => changeView('home')} 
            className="flex items-center gap-3 cursor-pointer group active-scale"
          >
            <div className={`w-10 h-10 bg-gradient-to-br ${themeColors[themeColor].split(' shadow-')[0]} text-white rounded-xl flex items-center justify-center font-bold text-xl shadow-lg transition-all duration-500 group-hover:rotate-12 group-hover:scale-110`}>
              {language === 'ar' || language === 'ur' ? 'ح' : 'H'}
            </div>
            <h1 className={`text-2xl font-black bg-clip-text text-transparent bg-gradient-to-r ${themeColors[themeColor].split(' shadow-')[0]} tracking-tight transition-all duration-500 group-hover:tracking-normal`}>
              {t.title}
            </h1>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <LanguagePicker currentLanguage={language} onLanguageChange={changeLanguage} />
            {view !== 'home' && (
              <button onClick={() => changeView('home')} className="p-2 md:px-4 md:py-2 bg-white border border-slate-200 rounded-xl hover-lift active-scale transition-colors flex items-center gap-2 font-bold text-slate-600 shadow-sm">
                <Home size={20} />
                <span className="hidden md:inline">{t.home}</span>
              </button>
            )}
            <button onClick={() => changeView('settings')} className={`p-2 md:px-4 md:py-2 bg-slate-100 text-slate-700 border border-slate-200 rounded-xl hover-lift active-scale transition-colors flex items-center gap-2 font-bold shadow-sm group`}>
              <span className="hidden md:inline">{t.settings}</span>
              <SettingsIcon size={20} className="transition-transform group-hover:rotate-90" />
            </button>
          </div>
        </div>
      </header>

      <main className={`flex-1 max-w-7xl mx-auto w-full p-4 md:p-8 transition-all duration-500 ${isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
        {view !== 'home' && (
          <button onClick={() => changeView('home')} className={`mb-6 flex items-center text-sm font-bold text-slate-400 hover:text-indigo-600 transition-all active-scale`}>
             <ChevronLeft size={16} className="rtl:rotate-180 me-1" /> {t.back}
          </button>
        )}
        <div className="animate-fade-in">
          {renderView()}
        </div>
      </main>

      <footer className="p-6 text-center border-t border-slate-200 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-center gap-4 text-xs font-bold uppercase tracking-widest text-slate-400">
          <span className="flex items-center gap-1 text-amber-500 animate-pulse"><Sparkles size={14} /> {language === 'ar' ? 'فكرة ذكية!' : 'Smart Idea!'}</span>
          <span>•</span>
          <span className="text-emerald-500">{language === 'ar' ? 'استمر 👌' : 'Keep Going 👌'}</span>
          <span>•</span>
          <span className="text-blue-500">{language === 'ar' ? 'أنت تتقدم' : 'You are advancing'}</span>
          <span>•</span>
          <span className="text-purple-500">{language === 'ar' ? 'عقلك يعمل جيدًا اليوم' : 'Your mind works well today'}</span>
        </div>
      </footer>
    </div>
  );
};

const Onboarding: React.FC<{ onEnter: () => void, language: Language, t: any, onLanguageChange: (lang: Language) => void }> = ({ onEnter, language, t, onLanguageChange }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800 text-white text-center overflow-hidden">
      <div className="absolute top-8 left-8 sm:left-auto sm:right-8">
        <LanguagePicker currentLanguage={language} onLanguageChange={onLanguageChange} />
      </div>
      <div className="w-24 h-24 bg-white text-indigo-900 rounded-[2.5rem] flex items-center justify-center font-black text-5xl mb-8 shadow-2xl animate-scale-in">
        {language === 'ar' || language === 'ur' ? 'ح' : 'H'}
      </div>
      <h1 className="text-5xl font-black mb-4 tracking-tighter animate-slide-up stagger-1">{t.onboarding_title}</h1>
      <p className="text-xl opacity-80 mb-12 max-w-md leading-relaxed font-light animate-slide-up stagger-2">{t.onboarding_desc}</p>
      <div className="space-y-4 w-full max-w-xs animate-slide-up stagger-3">
        <button onClick={onEnter} className="w-full py-5 bg-white text-indigo-900 font-bold rounded-2xl text-xl shadow-xl hover-lift active-scale transition-all">{t.start_now}</button>
        <button className="w-full py-5 border-2 border-white/20 hover:bg-white/10 font-bold rounded-2xl text-xl transition-all active-scale">{t.login}</button>
        <button onClick={onEnter} className="w-full py-2 text-sm opacity-50 hover:opacity-100 transition-opacity">{t.guest}</button>
      </div>
    </div>
  );
};

const HomeView: React.FC<{ setView: (v: View) => void, language: Language, t: any }> = ({ setView, language, t }) => {
  const menuItems = [
    { id: 'clock', icon: ClockIcon, label: t.clock, color: 'from-emerald-500 to-teal-600', bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-100', shadow: 'shadow-emerald-100', desc: 'Study' },
    { id: 'notes', icon: FileText, label: t.notes, color: 'from-amber-400 to-orange-500', bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-100', shadow: 'shadow-amber-100', desc: 'Notes' },
    { id: 'ai', icon: MessageSquare, label: t.ai, color: 'from-indigo-600 to-purple-600', bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-100', shadow: 'shadow-indigo-100', desc: 'Ask' },
    { id: 'search', icon: SearchIcon, label: t.search, color: 'from-blue-500 to-cyan-500', bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-100', shadow: 'shadow-blue-100', desc: 'Search' },
    { id: 'library', icon: BookOpen, label: t.library, color: 'from-rose-500 to-pink-600', bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-100', shadow: 'shadow-rose-100', desc: 'Read' },
    { id: 'tasks', icon: CheckSquare, label: t.tasks, color: 'from-sky-500 to-indigo-500', bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-100', shadow: 'shadow-sky-100', desc: 'Work' },
    { id: 'innovation', icon: Lightbulb, label: t.innovation, color: 'from-yellow-400 to-amber-600', bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-100', shadow: 'shadow-yellow-100', desc: 'Innovate' },
    { id: 'khulas', icon: Target, label: t.khulas, color: 'from-slate-700 to-slate-900', bg: 'bg-slate-100', text: 'text-slate-800', border: 'border-slate-200', shadow: 'shadow-slate-100', desc: 'Review' },
    { id: 'community', icon: Share2, label: t.community, color: 'from-purple-500 to-violet-600', bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-100', shadow: 'shadow-purple-100', desc: 'Create' },
  ];

  return (
    <div className="space-y-12 animate-fade-in">
      <div className="text-center md:text-start">
        <h2 className="text-4xl font-black text-slate-800 mb-3 tracking-tight">{t.onboarding_title}</h2>
        <p className="text-lg text-slate-500 font-medium">{language === 'ar' ? 'ماذا تريد أن تفعل اليوم؟ اختر وجهتك لتبدأ' : 'What would you like to do today? Select to start.'}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
        {menuItems.map((item, idx) => (
          <button 
            key={item.id}
            onClick={() => setView(item.id as View)}
            className={`group relative flex flex-col items-center justify-center aspect-square rounded-[2.5rem] border ${item.border} ${item.bg} p-6 transition-all hover-lift active-scale shadow-xl ${item.shadow} hover:shadow-2xl animate-slide-up`}
            style={{ animationDelay: `${idx * 0.05}s` }}
          >
            <div className={`absolute top-4 pe-6 text-[11px] font-black uppercase tracking-widest ${item.text} opacity-50 group-hover:opacity-100 transition-opacity`}>
              {item.desc}
            </div>
            <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${item.color} text-white flex items-center justify-center mb-4 shadow-lg shadow-current/20 group-hover:rotate-12 transition-transform duration-500`}>
              <item.icon size={40} strokeWidth={2} />
            </div>
            <span className={`text-lg font-bold ${item.text}`}>{item.label}</span>
          </button>
        ))}
      </div>

      <div className="bg-white p-8 md:p-12 rounded-[3rem] border border-slate-100 flex flex-col md:flex-row items-center gap-8 shadow-2xl shadow-slate-200/50 animate-slide-up stagger-3">
        <div className="flex-1 space-y-6 text-center md:text-start">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-full text-sm font-bold">
            <Sparkles size={16} className="animate-pulse" /> {t.khulas}
          </div>
          <h3 className="text-3xl font-black text-slate-800 tracking-tight">{t.summary_title}</h3>
          <p className="text-lg text-slate-500 leading-relaxed max-w-xl">
            {language === 'ar' 
              ? 'عقلك يعمل جيداً اليوم! لقد كنت منتجاً في العمل والابتكار. استمر في هذا الأداء الرائع.'
              : 'Your mind is working well today! You have been productive in work and innovation. Keep it up.'}
          </p>
          <button onClick={() => setView('khulas')} className="px-8 py-3 bg-slate-900 text-white rounded-2xl font-bold shadow-lg hover:bg-slate-800 transition-colors hover-lift active-scale">
             {t.summary_desc}
          </button>
        </div>
        <div className="w-full md:w-1/3 p-1 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-[2.5rem] animate-scale-in">
          <div className="h-full bg-white rounded-[2.4rem] flex flex-col items-center justify-center p-8 text-center shadow-inner">
            <div className="text-6xl font-black bg-clip-text text-transparent bg-gradient-to-br from-indigo-600 to-purple-600 transition-all duration-700 hover:scale-110">١٠٠٪</div>
            <div className="text-sm uppercase font-black tracking-widest text-slate-400 mt-2">{t.summary_progress}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
