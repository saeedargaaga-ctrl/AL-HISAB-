
export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: number;
}

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
}

export interface Book {
  id: string;
  title: string;
  author: string;
  content: string;
  coverImage?: string;
}

export interface Idea {
  id: string;
  title: string;
  description: string;
  status: 'new' | 'developing' | 'evaluated';
}

export interface Post {
  id: string;
  type: 'image' | 'video' | 'article';
  title: string;
  content: string; // URL for media or text for article
  description?: string;
  createdAt: number;
}

export type Language = 'ar' | 'en' | 'ur' | 'ru' | 'zh';
export type ThemeColor = 'indigo' | 'rose' | 'emerald' | 'amber' | 'blue' | 'purple' | 'slate';

export type View = 'onboarding' | 'home' | 'clock' | 'notes' | 'ai' | 'search' | 'library' | 'tasks' | 'innovation' | 'community' | 'settings' | 'khulas';

export interface AppState {
  view: View;
  language: Language;
  themeColor: ThemeColor;
  notes: Note[];
  tasks: Task[];
  books: Book[];
  ideas: Idea[];
  posts: Post[];
  userName: string;
}
