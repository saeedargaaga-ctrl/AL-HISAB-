
import React from 'react';
import { Target, Zap, Book, Lightbulb, FileText, CheckCircle } from 'lucide-react';
import { Note, Task, Book as BookType, Idea } from '../types';

interface SummaryProps {
  t: any;
  notes: Note[];
  tasks: Task[];
  books: BookType[];
  ideas: Idea[];
}

export const Summary: React.FC<SummaryProps> = ({ t, notes, tasks, books, ideas }) => {
  const completedTasks = tasks.filter(t => t.completed).length;

  const stats = [
    { label: t.summary_tasks, value: completedTasks, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: t.summary_ideas, value: ideas.length, icon: Lightbulb, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: t.summary_books, value: books.length, icon: Book, color: 'text-rose-600', bg: 'bg-rose-50' },
    { label: t.summary_notes, value: notes.length, icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' }
  ];

  return (
    <div className="space-y-12 max-w-5xl mx-auto py-6">
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-[2rem] mx-auto flex items-center justify-center shadow-xl">
          <Target size={40} />
        </div>
        <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.khulas}</h2>
        <p className="text-lg text-slate-500 font-medium">{t.summary_desc}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="p-8 rounded-[2.5rem] bg-white border border-slate-100 flex flex-col items-center text-center space-y-2">
            <div className={`w-12 h-12 rounded-2xl ${stat.bg} ${stat.color} flex items-center justify-center mb-2`}><stat.icon size={24} /></div>
            <div className="text-3xl font-black text-slate-800">{stat.value}</div>
            <div className="text-sm font-bold text-slate-400 uppercase tracking-widest">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="p-10 bg-white border border-slate-100 rounded-[3rem] space-y-6">
          <h3 className="text-2xl font-black text-slate-800 flex items-center gap-3"><Zap className="text-amber-500" /> {t.summary_state}</h3>
          <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-indigo-500 to-purple-600 w-3/4"></div>
          </div>
          <div className="flex justify-between text-xs font-black text-slate-400 uppercase tracking-widest">
            <span>{t.summary_progress.split(' vs ')[0]}</span>
            <span>{t.summary_progress.split(' vs ')[1]}</span>
          </div>
        </div>

        <div className="p-10 bg-slate-900 text-white rounded-[3rem] space-y-6">
          <h3 className="text-2xl font-black">{t.summary_tip}</h3>
          <p className="text-indigo-100/80 text-lg font-light italic">
            {document.documentElement.lang === 'ar' 
              ? '"العقل الواضح هو العقل المنظم. خصص ٥ دقائق الآن لإعادة مراجعة أهم مهمة في قائمة \'العمل والدراسة\' وركز عليها حصرياً."'
              : '"A clear mind is an organized mind. Dedicate 5 minutes now to review your most important task."'}
          </p>
        </div>
      </div>
    </div>
  );
};
