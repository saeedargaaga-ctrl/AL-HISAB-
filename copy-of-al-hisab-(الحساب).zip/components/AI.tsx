
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, Loader2, Mic, MicOff } from 'lucide-react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { chatWithAI } from '../services/gemini';
import { Language } from '../types';

export const AIAssistant: React.FC<{ t: any, language: Language }> = ({ t, language }) => {
  const [messages, setMessages] = useState<{role: 'user'|'bot', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Live API refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scriptNodeRef = useRef<ScriptProcessorNode | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isLoading]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopRecording();
    };
  }, []);

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const createBlob = (data: Float32Array) => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = audioContext.createMediaStreamSource(stream);
            const scriptProcessor = audioContext.createScriptProcessor(4096, 1, 1);
            scriptNodeRef.current = scriptProcessor;
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContext.destination);
            setIsRecording(true);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              if (text) {
                // We use function update to ensure we have the latest state
                setInput((prev) => prev + (prev && !prev.endsWith(' ') ? ' ' : '') + text);
              }
            }
          },
          onerror: (e) => {
            console.error('Live API Error:', e);
            stopRecording();
          },
          onclose: () => setIsRecording(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          systemInstruction: 'You are a transcription assistant for the Al-Hisab app. Your only job is to provide real-time transcription for the user so they can fill a chat input field. Do not respond with audio.',
        },
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start recording:', err);
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (scriptNodeRef.current) {
      scriptNodeRef.current.disconnect();
      scriptNodeRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(console.error);
      audioContextRef.current = null;
    }
    setIsRecording(false);
  };

  const handleMicToggle = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    
    // Stop recording if active before sending to avoid conflicting streams
    if (isRecording) stopRecording();

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const response = await chatWithAI(userMsg, language, messages);
      setMessages(prev => [...prev, { role: 'bot', text: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'bot', text: language === 'ar' ? 'عذراً، حدث خطأ ما.' : 'Sorry, something went wrong.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[75vh] max-w-3xl mx-auto bg-white border border-slate-100 rounded-[3rem] overflow-hidden shadow-2xl shadow-indigo-100/50 animate-scale-in">
      <div className="p-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 text-white flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md transition-transform hover:rotate-12">
            <Bot size={28} />
          </div>
          <div>
            <h3 className="font-black text-xl">{t.ai}</h3>
            <p className="text-xs text-indigo-100 font-bold opacity-80 uppercase tracking-widest">{t.ai_desc.split('.')[0]}</p>
          </div>
        </div>
        <Sparkles size={24} className="text-amber-300 animate-pulse" />
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar bg-slate-50/30">
        {messages.length === 0 && (
          <div className="text-center py-12 animate-fade-in">
            <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-[2rem] mx-auto flex items-center justify-center mb-6 shadow-lg shadow-indigo-50 animate-scale-in">
              <Sparkles size={40} />
            </div>
            <h4 className="text-2xl font-black text-slate-800 mb-2">{t.ai_help}</h4>
            <p className="text-slate-400 font-medium mb-8">{t.ai_desc}</p>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={`flex animate-slide-up ${m.role === 'user' ? 'justify-start' : 'justify-end'}`}>
            <div className={`max-w-[85%] p-5 rounded-[2rem] shadow-sm flex items-start gap-4 transition-transform duration-500 hover:scale-[1.01] ${m.role === 'user' ? 'bg-white border border-slate-100 text-slate-800 rounded-tr-none' : 'bg-gradient-to-br from-indigo-600 to-purple-600 text-white rounded-tl-none shadow-indigo-100'}`}>
              <div className={`shrink-0 mt-1 w-8 h-8 rounded-xl flex items-center justify-center ${m.role === 'user' ? 'bg-indigo-50 text-indigo-500' : 'bg-white/20'}`}>
                {m.role === 'user' ? <User size={18}/> : <Bot size={18}/>}
              </div>
              <div className="text-base leading-loose whitespace-pre-wrap font-medium">
                {m.text}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-end animate-fade-in">
            <div className="bg-gradient-to-br from-indigo-600 to-purple-600 text-white p-5 rounded-[2rem] rounded-tl-none shadow-xl shadow-indigo-100 flex items-center gap-3">
              <div className="flex gap-1.5">
                <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              </div>
              <span className="text-sm font-bold opacity-80">{t.ai_thinking}</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white border-t border-slate-50 flex gap-3 relative">
        <input 
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder={t.ai_placeholder}
          className="flex-1 px-6 py-4 outline-none bg-slate-50 rounded-2xl text-lg font-medium text-slate-700 focus:ring-2 ring-indigo-100 transition-all placeholder:text-slate-300"
        />
        <div className="flex gap-2">
          <button
            onClick={handleMicToggle}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all hover-lift active-scale shadow-lg ${isRecording ? 'bg-rose-500 text-white animate-pulse shadow-rose-200' : 'bg-slate-100 text-slate-500 shadow-slate-200'}`}
            title={isRecording ? "Stop listening" : "Start voice input"}
            aria-label={isRecording ? "Stop listening" : "Start voice input"}
          >
            {isRecording ? <MicOff size={24} /> : <Mic size={24} />}
          </button>
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-purple-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200 transition-all hover-lift active-scale disabled:opacity-30"
            aria-label="Send message"
          >
            {isLoading ? <Loader2 className="animate-spin" size={24} /> : <Send size={24} />}
          </button>
        </div>
      </div>
    </div>
  );
};
