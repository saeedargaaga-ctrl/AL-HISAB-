
import React from 'react';
import { Globe, Palette, Shield, Cpu, Database, LogOut, Check } from 'lucide-react';
import { Language, ThemeColor } from '../types';
import { translations } from '../services/translations';
import { LanguagePicker } from './LanguagePicker';

interface SettingsProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  themeColor: ThemeColor;
  onThemeChange: (theme: ThemeColor) => void;
  onLogout: () => void;
}

export const Settings: React.FC<SettingsProps> = ({ language, onLanguageChange, themeColor, onThemeChange, onLogout }) => {
  const t = translations[language];

  const themes: { id: ThemeColor; color: string; bg: string }[] = [
    { id: 'indigo', color: 'bg-indigo-600', bg: 'bg-indigo-50' },
    { id: 'rose', color: 'bg-rose-600', bg: 'bg-rose-50' },
    { id: 'emerald', color: 'bg-emerald-600', bg: 'bg-emerald-50' },
    { id: 'amber', color: 'bg-amber-500', bg: 'bg-amber-50' },
    { id: 'blue', color: 'bg-blue-600', bg: 'bg-blue-50' },
    { id: 'purple', color: 'bg-purple-600', bg: 'bg-purple-50' },
    { id: 'slate', color: 'bg-slate-800', bg: 'bg-slate-100' }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 animate-fade-in">
      <div className="text-center md:text-right space-y-2 mb-10">
        <h2 className="text-4xl font-black text-slate-800">{t.settings}</h2>
        <p className="text-slate-500 font-medium">
          {language === 'ar' ? 'قم بتخصيص تجربتك الفريدة في تطبيق الحساب' : 'Customize your unique experience in Al-Hisab'}
        </p>
      </div>

      <div className="grid gap-6">
        {/* Language Selection */}
        <section className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-xl shadow-slate-100/50 hover-lift transition-all">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
              <Globe size={24} />
            </div>
            <h3 className="text-xl font-black text-slate-800">{t.lang}</h3>
          </div>
          <LanguagePicker currentLanguage={language} onLanguageChange={onLanguageChange} variant="full" />
        </section>

        {/* Theme/Color Selection */}
        <section className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-xl shadow-slate-100/50 hover-lift transition-all">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center">
              <Palette size={24} />
            </div>
            <h3 className="text-xl font-black text-slate-800">{t.theme}</h3>
          </div>
          <div className="flex flex-wrap gap-4">
            {themes.map((tColor) => (
              <button
                key={tColor.id}
                onClick={() => onThemeChange(tColor.id)}
                className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all active-scale hover-lift ${
                  tColor.bg
                } border-2 ${
                  themeColor === tColor.id ? 'border-slate-800 scale-110 shadow-lg' : 'border-transparent'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl ${tColor.color} flex items-center justify-center text-white`}>
                  {themeColor === tColor.id && <Check size={20} />}
                </div>
              </button>
            ))}
          </div>
        </section>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Privacy */}
          <section className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-xl shadow-slate-100/50 hover-lift transition-all">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
                <Shield size={20} />
              </div>
              <h3 className="text-lg font-black text-slate-800">{t.privacy}</h3>
            </div>
            <p className="text-sm text-slate-500 mb-4">
              {language === 'ar' ? 'بياناتك مشفرة ومحمية محلياً وفي السحاب.' : 'Your data is encrypted and protected locally and in the cloud.'}
            </p>
            <button className="text-rose-600 font-bold text-sm hover:underline active-scale">
              {language === 'ar' ? 'عرض إعدادات الخصوصية' : 'View Privacy Settings'}
            </button>
          </section>

          {/* AI Config */}
          <section className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-xl shadow-slate-100/50 hover-lift transition-all">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                <Cpu size={20} />
              </div>
              <h3 className="text-lg font-black text-slate-800">{t.ai}</h3>
            </div>
            <p className="text-sm text-slate-500 mb-4">
              {language === 'ar' ? 'تخصيص مساعدك الذكي ونماذج التوليد.' : 'Customize your smart assistant and generation models.'}
            </p>
            <button className="text-indigo-600 font-bold text-sm hover:underline active-scale">
              {language === 'ar' ? 'إعدادات الذكاء الاصطناعي' : 'AI Settings'}
            </button>
          </section>
        </div>

        {/* Backup & Logout */}
        <section className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-xl shadow-slate-100/50">
          <div className="flex flex-col md:flex-row gap-4">
            <button className="flex-1 flex items-center justify-center gap-3 py-4 bg-slate-50 text-slate-700 rounded-2xl font-bold hover:bg-slate-100 hover-lift active-scale transition-all">
              <Database size={20} />
              {t.backup}
            </button>
            <button 
              onClick={onLogout}
              className="flex-1 flex items-center justify-center gap-3 py-4 bg-rose-50 text-rose-600 rounded-2xl font-bold hover:bg-rose-100 hover-lift active-scale transition-all"
            >
              <LogOut size={20} />
              {t.logout}
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
