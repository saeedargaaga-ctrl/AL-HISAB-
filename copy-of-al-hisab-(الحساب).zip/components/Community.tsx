
import React, { useState } from 'react';
import { Share2, Image as ImageIcon, Video, FileText, Plus, Loader2, Sparkles, Trash2, Heart } from 'lucide-react';
import { Post, Language } from '../types';
import { generateImage, generateVideo, optimizeText } from '../services/gemini';

export const Community: React.FC<{ t: any, posts: Post[], language: Language, onPublish: (post: Post) => void, onDelete: (id: string) => void }> = ({ t, posts, language, onPublish, onDelete }) => {
  const [activeTab, setActiveTab] = useState<'feed' | 'create'>('feed');
  const [createType, setCreateType] = useState<'image' | 'video' | 'article'>('image');
  const [prompt, setPrompt] = useState('');
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!prompt.trim() && createType !== 'article') return;
    setLoading(true);
    try {
      let content = '';
      if (createType === 'video') content = await generateVideo(prompt);
      else if (createType === 'image') content = await generateImage(prompt) || '';
      else content = await optimizeText(prompt, language);

      onPublish({
        id: Date.now().toString(),
        type: createType,
        title: title || t.scenes_view,
        content,
        description: prompt,
        createdAt: Date.now()
      });
      setActiveTab('feed');
      setPrompt('');
      setTitle('');
    } finally {
      setLoading(false);
    }
  };

  const types = [
    { id: 'image', icon: ImageIcon, label: t.scenes_type_image },
    { id: 'video', icon: Video, label: t.scenes_type_video },
    { id: 'article', icon: FileText, label: t.scenes_type_article }
  ];

  return (
    <div className="space-y-12 max-w-6xl mx-auto py-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="text-center md:text-right">
          <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.scenes_title}</h2>
          <p className="text-lg text-slate-500 font-medium">{t.scenes_desc}</p>
        </div>
        <div className="flex p-1.5 bg-white border border-slate-100 rounded-[2rem] shadow-xl">
          <button onClick={() => setActiveTab('feed')} className={`px-10 py-4 rounded-[1.5rem] transition-all font-black ${activeTab === 'feed' ? 'bg-slate-900 text-white' : 'text-slate-400'}`}>{t.scenes_view}</button>
          <button onClick={() => setActiveTab('create')} className={`px-10 py-4 rounded-[1.5rem] transition-all font-black ${activeTab === 'create' ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white' : 'text-slate-400'}`}>{t.scenes_add}</button>
        </div>
      </div>

      {activeTab === 'create' ? (
        <div className="bg-white border border-slate-50 rounded-[3rem] p-10 md:p-16 space-y-12 shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {types.map(type => (
              <button key={type.id} onClick={() => setCreateType(type.id as any)} className={`flex flex-col items-center justify-center p-8 rounded-[2.5rem] border-2 transition-all ${createType === type.id ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-50 bg-white text-slate-400'}`}>
                <type.icon size={36} className="mb-4" />
                <span className="font-black text-lg">{type.label}</span>
              </button>
            ))}
          </div>
          <input 
            placeholder={t.scenes_title_ph}
            value={title}
            onChange={e => setTitle(e.target.value)}
            className="w-full text-3xl font-black p-4 border-b-4 border-purple-100 outline-none"
          />
          <textarea 
            placeholder={createType === 'article' ? t.scenes_article_ph : t.scenes_prompt_ph}
            value={prompt}
            onChange={e => setPrompt(e.target.value)}
            className="w-full h-64 p-8 border-2 border-slate-50 rounded-[2.5rem] outline-none"
          />
          <button onClick={handleCreate} disabled={loading} className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-2xl flex items-center justify-center gap-4">
            {loading ? <><Loader2 className="animate-spin" /> {t.scenes_publishing}</> : <><Sparkles size={28} /> {t.scenes_generate}</>}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {posts.map(post => (
            <div key={post.id} className="border border-slate-100 rounded-[3rem] overflow-hidden bg-white shadow-xl flex flex-col h-full">
              <div className="aspect-video bg-slate-50 relative">
                {post.type === 'image' && <img src={post.content} className="w-full h-full object-cover" />}
                {post.type === 'video' && <video src={post.content} className="w-full h-full object-cover" controls />}
                {post.type === 'article' && <div className="p-10 h-full bg-blue-50 flex items-center justify-center text-center font-black text-2xl text-blue-800">{post.title}</div>}
              </div>
              <div className="p-10 flex-1 flex flex-col space-y-6">
                <div className="flex justify-between items-start">
                  <h3 className="text-3xl font-black text-slate-800">{post.title}</h3>
                  <button onClick={() => onDelete(post.id)} className="p-3 text-slate-300 hover:text-rose-500"><Trash2 size={24} /></button>
                </div>
                <p className="flex-1 text-slate-500 text-lg font-medium">{post.description}</p>
                <div className="pt-6 border-t border-slate-50 flex justify-between items-center text-slate-300">
                  <div className="flex gap-4 font-black">
                    <button className="flex items-center gap-2"><Heart size={20} /> 12</button>
                    <button className="flex items-center gap-2"><Share2 size={20} /> {language === 'ar' ? 'مشاركة' : 'Share'}</button>
                  </div>
                  <span className="text-xs font-black uppercase tracking-widest">{new Date(post.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
