
import React, { useState } from 'react';
import { Lightbulb, Plus, Sparkles, Send, Trash2, Loader2, ChevronDown, ChevronUp, Zap } from 'lucide-react';
import { Idea, Language } from '../types';
import { evaluateIdea } from '../services/gemini';

export const Innovation: React.FC<{ t: any, ideas: Idea[], language: Language, onUpdate: (ideas: Idea[]) => void }> = ({ t, ideas, language, onUpdate }) => {
  const [view, setView] = useState<'list' | 'create'>('list');
  const [newIdea, setNewIdea] = useState({ title: '', description: '' });
  const [isEvaluating, setIsEvaluating] = useState<string | null>(null);
  const [evaluations, setEvaluations] = useState<Record<string, string>>({});
  const [expanded, setExpanded] = useState<string | null>(null);

  const handleAddIdea = () => {
    if (newIdea.title && newIdea.description) {
      const idea: Idea = {
        id: Date.now().toString(),
        title: newIdea.title,
        description: newIdea.description,
        status: 'new'
      };
      onUpdate([idea, ...ideas]);
      setView('list');
      setNewIdea({ title: '', description: '' });
    }
  };

  const handleEvaluate = async (idea: Idea) => {
    setIsEvaluating(idea.id);
    try {
      const result = await evaluateIdea(idea.title, idea.description, language);
      setEvaluations(prev => ({ ...prev, [idea.id]: result }));
      setExpanded(idea.id);
      onUpdate(ideas.map(i => i.id === idea.id ? { ...i, status: 'evaluated' } : i));
    } finally {
      setIsEvaluating(null);
    }
  };

  if (view === 'create') {
    return (
      <div className="max-w-3xl mx-auto space-y-12 py-6">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-[1.5rem] mx-auto flex items-center justify-center shadow-lg shadow-amber-50">
            <Plus size={32} />
          </div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.inn_create_title}</h2>
          <p className="text-lg text-slate-500 font-medium">{t.inn_desc_ph.split('?')[0]}</p>
        </div>

        <div className="bg-white p-10 border border-slate-100 rounded-[3rem] shadow-2xl shadow-amber-100/50 space-y-10">
          <input 
            placeholder={t.inn_title_ph}
            value={newIdea.title}
            onChange={e => setNewIdea({...newIdea, title: e.target.value})}
            className="w-full text-3xl font-black p-4 border-b-4 border-amber-100 outline-none focus:border-amber-500 transition-colors bg-transparent text-slate-800"
          />
          <textarea 
            placeholder={t.inn_desc_ph}
            value={newIdea.description}
            onChange={e => setNewIdea({...newIdea, description: e.target.value})}
            className="w-full h-64 p-6 border-2 border-slate-50 rounded-[2rem] outline-none focus:border-amber-200 transition-all resize-none text-xl leading-relaxed font-medium text-slate-700 bg-slate-50/50"
          />
          <div className="flex gap-4">
            <button onClick={() => setView('list')} className="flex-1 py-5 border-2 border-slate-100 rounded-[1.5rem] font-black text-slate-500">{t.cancel}</button>
            <button onClick={handleAddIdea} className="flex-[2] py-5 bg-slate-900 text-white rounded-[1.5rem] font-black text-xl flex items-center justify-center gap-3">{t.inn_save}</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-start">
          <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.inn_center}</h2>
          <p className="text-lg text-slate-500 font-medium">{t.inn_desc}</p>
        </div>
        <button 
          onClick={() => setView('create')}
          className="bg-gradient-to-r from-amber-400 to-amber-600 text-white px-10 py-5 rounded-[2rem] font-black text-lg flex items-center gap-3 shadow-2xl shadow-amber-200 hover:scale-[1.05] transition-all"
        >
          <Plus size={28} /> {t.inn_new}
        </button>
      </div>

      <div className="grid gap-10">
        {ideas.map(idea => (
          <div key={idea.id} className="border border-slate-100 rounded-[3rem] overflow-hidden bg-white shadow-xl">
            <div className="p-8 md:p-12 space-y-6">
              <div className="flex justify-between items-start">
                <h3 className="text-3xl font-black text-slate-800 tracking-tight">{idea.title}</h3>
                <button 
                  onClick={() => handleEvaluate(idea)}
                  disabled={isEvaluating === idea.id}
                  className="flex items-center justify-center gap-3 px-8 py-3 bg-slate-900 text-white rounded-2xl font-black shadow-lg hover:bg-slate-800"
                >
                  {isEvaluating === idea.id ? <Loader2 className="animate-spin" size={20} /> : <Sparkles size={20} className="text-amber-400" />}
                  {t.inn_evaluate}
                </button>
              </div>
              <p className="text-xl text-slate-600 font-medium text-start">{idea.description}</p>
              
              {evaluations[idea.id] && (
                <div className="mt-8 pt-8 border-t-2 border-slate-50">
                  <button 
                    onClick={() => setExpanded(expanded === idea.id ? null : idea.id)}
                    className="flex items-center gap-3 font-black text-amber-600 text-start w-full"
                  >
                    <ChevronDown size={24} className={`transition-transform ${expanded === idea.id ? 'rotate-180' : ''}`} />
                    {t.inn_ai_insights}
                  </button>
                  {expanded === idea.id && (
                    <div className="p-10 bg-amber-50 rounded-[2.5rem] prose prose-amber mt-4 text-start">
                      {evaluations[idea.id]}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        {ideas.length === 0 && (
          <div className="py-32 text-center border-4 border-dashed border-amber-50 rounded-[4rem] bg-amber-50/20">
            <Lightbulb size={64} className="mx-auto text-amber-200 mb-6" />
            <p className="text-2xl font-black text-amber-400">{t.inn_empty}</p>
            <button onClick={() => setView('create')} className="mt-6 px-10 py-4 bg-amber-600 text-white rounded-2xl font-black">{t.inn_first}</button>
          </div>
        )}
      </div>
    </div>
  );
};
