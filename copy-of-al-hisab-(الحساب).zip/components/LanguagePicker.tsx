
import React, { useState } from 'react';
import { Languages, ChevronDown, Check } from 'lucide-react';
import { Language } from '../types';

interface LanguagePickerProps {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  variant?: 'minimal' | 'full';
}

const languages: { code: Language; name: string; native: string }[] = [
  { code: 'ar', name: 'Arabic', native: 'العربية' },
  { code: 'en', name: 'English', native: 'English' },
  { code: 'ur', name: 'Urdu', native: 'اردو (پاکستان)' },
  { code: 'ru', name: 'Russian', native: 'Русский' },
  { code: 'zh', name: 'Chinese', native: '中文' }
];

export const LanguagePicker: React.FC<LanguagePickerProps> = ({ currentLanguage, onLanguageChange, variant = 'minimal' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const selected = languages.find(l => l.code === currentLanguage);

  if (variant === 'full') {
    return (
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => onLanguageChange(lang.code)}
            className={`p-4 rounded-2xl font-bold border-2 transition-all active-scale hover-lift text-start ${
              currentLanguage === lang.code
                ? 'border-indigo-600 bg-indigo-600 text-white shadow-lg shadow-indigo-100'
                : 'border-slate-50 bg-slate-50 text-slate-500 hover:border-indigo-200'
            }`}
          >
            <div className="text-[10px] uppercase tracking-widest font-black opacity-60 mb-1">{lang.name}</div>
            <div className="text-lg leading-tight">{lang.native}</div>
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 rounded-xl hover-lift active-scale text-slate-600 font-bold shadow-sm transition-all"
      >
        <Languages size={18} className="text-indigo-500" />
        <span className="hidden sm:inline text-sm">{selected?.native}</span>
        <ChevronDown size={14} className={`transition-transform duration-300 opacity-40 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)}></div>
          <div className={`absolute top-full mt-2 inset-inline-end-0 bg-white border border-slate-100 rounded-2xl shadow-2xl p-2 z-50 min-w-[200px] animate-scale-in`}>
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => {
                  onLanguageChange(lang.code);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all group ${
                  currentLanguage === lang.code ? 'bg-indigo-50 text-indigo-700' : 'hover:bg-slate-50 text-slate-600'
                }`}
              >
                <div className="flex flex-col items-start text-start">
                  <span className="text-[9px] uppercase tracking-widest font-black opacity-40 group-hover:opacity-60 transition-opacity">{lang.name}</span>
                  <span className="font-bold">{lang.native}</span>
                </div>
                {currentLanguage === lang.code && <Check size={16} className="text-indigo-600" />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
};
