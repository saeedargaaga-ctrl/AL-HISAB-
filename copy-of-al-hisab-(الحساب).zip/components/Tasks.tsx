
import React, { useState } from 'react';
import { Plus, CheckCircle, Circle, Trash2, Flag, Target, Zap } from 'lucide-react';
import { Task } from '../types';

export const Tasks: React.FC<{ t: any, tasks: Task[], onUpdate: (tasks: Task[]) => void }> = ({ t, tasks, onUpdate }) => {
  const [newText, setNewText] = useState('');
  const [priority, setPriority] = useState<Task['priority']>('medium');

  const addTask = () => {
    if (!newText.trim()) return;
    const newTask: Task = {
      id: Date.now().toString(),
      text: newText.trim(),
      completed: false,
      priority
    };
    onUpdate([newTask, ...tasks]);
    setNewText('');
  };

  const toggleTask = (id: string) => {
    onUpdate(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    onUpdate(tasks.filter(t => t.id !== id));
  };

  const priorityMeta = {
    low: { color: 'text-slate-400 bg-slate-50 border-slate-200', active: 'bg-slate-500 text-white', label: t.tasks_low },
    medium: { color: 'text-blue-500 bg-blue-50 border-blue-100', active: 'bg-blue-600 text-white', label: t.tasks_medium },
    high: { color: 'text-rose-500 bg-rose-50 border-rose-100', active: 'bg-rose-600 text-white', label: t.tasks_high }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-12 py-6">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-sky-100 text-sky-600 rounded-[1.5rem] mx-auto flex items-center justify-center shadow-lg shadow-sky-50">
          <Target size={32} />
        </div>
        <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.tasks_plan}</h2>
        <p className="text-lg text-slate-500 font-medium">{t.tasks_desc}</p>
      </div>

      <div className="p-8 bg-white border border-slate-100 rounded-[3rem] shadow-2xl shadow-slate-200/50 space-y-8 relative overflow-hidden">
        <div className="relative space-y-6">
          <div className="flex gap-4">
            <input
              value={newText}
              onChange={e => setNewText(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addTask()}
              placeholder={t.tasks_add_ph}
              className="flex-1 p-5 text-xl font-medium bg-slate-50 border-2 border-slate-50 rounded-[1.5rem] outline-none focus:bg-white focus:border-sky-400 transition-all placeholder:text-slate-300"
            />
            <button 
              onClick={addTask}
              className="bg-slate-900 text-white px-10 rounded-[1.5rem] font-black text-lg hover:bg-slate-800 shadow-xl shadow-slate-200 transition-all active:scale-95"
            >
              {t.add}
            </button>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{t.tasks_priority}</span>
            <div className="flex gap-2">
              {(['low', 'medium', 'high'] as const).map(p => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={`px-6 py-2 rounded-xl text-sm font-black border-2 transition-all ${priority === p ? priorityMeta[p].active + ' border-transparent shadow-lg' : 'bg-white border-slate-100 text-slate-400 hover:border-slate-200'}`}
                >
                  {priorityMeta[p].label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {tasks.map(task => (
          <div 
            key={task.id}
            className={`flex items-center gap-6 p-6 border border-slate-100 rounded-[2rem] group transition-all duration-500 ${task.completed ? 'bg-slate-50/50 opacity-60' : 'bg-white shadow-lg shadow-slate-100/50 hover:shadow-xl hover:shadow-sky-100/50 hover:-translate-y-1'}`}
          >
            <button onClick={() => toggleTask(task.id)} className="shrink-0 transition-all active:scale-90 focus:outline-none">
              {task.completed ? (
                <div className="w-10 h-10 bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-emerald-200">
                  <CheckCircle size={24} />
                </div>
              ) : (
                <div className="w-10 h-10 border-4 border-slate-100 rounded-full flex items-center justify-center group-hover:border-sky-400 transition-colors bg-white">
                  <Circle className="text-transparent group-hover:text-sky-100" size={20} />
                </div>
              )}
            </button>
            <span className={`flex-1 text-xl font-bold tracking-tight ${task.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>
              {task.text}
            </span>
            <div className="flex items-center gap-4">
              <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest ${priorityMeta[task.priority].color}`}>
                <Flag size={14} fill="currentColor" />
                {priorityMeta[task.priority].label}
              </div>
              <button onClick={() => deleteTask(task.id)} className="opacity-0 group-hover:opacity-100 text-rose-300 hover:text-rose-600 transition-all">
                <Trash2 size={24} />
              </button>
            </div>
          </div>
        ))}

        {tasks.length === 0 && (
          <div className="py-24 text-center border-4 border-dashed border-slate-50 rounded-[4rem] bg-slate-50/20 text-slate-300 flex flex-col items-center gap-4">
            <Zap size={64} className="opacity-20" />
            <p className="text-xl font-black opacity-40">{t.tasks_empty}</p>
          </div>
        )}
      </div>

      {tasks.length > 0 && (
        <div className="text-center pt-8">
          <p className="text-sm font-black text-slate-300 uppercase tracking-widest flex items-center justify-center gap-2">
            <div className="w-10 h-1 bg-slate-100 rounded-full"></div>
            {t.tasks_great}
            <div className="w-10 h-1 bg-slate-100 rounded-full"></div>
          </p>
        </div>
      )}
    </div>
  );
};
