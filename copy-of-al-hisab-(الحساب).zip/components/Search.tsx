
import React, { useState } from 'react';
import { Search as SearchIcon, ExternalLink, Loader2, Sparkles, Globe } from 'lucide-react';
import { summarizeSearch } from '../services/gemini';
import { Language } from '../types';

export const Search: React.FC<{ t: any, language: Language }> = ({ t, language }) => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<{ text: string, sources: any[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const data = await summarizeSearch(query, language);
      setResult(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 py-6">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-[1.5rem] mx-auto flex items-center justify-center shadow-lg shadow-blue-50">
          <Globe size={32} />
        </div>
        <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.search_title}</h2>
        <p className="text-lg text-slate-500 font-medium">{t.search_desc}</p>
      </div>

      <div className="relative group max-w-2xl mx-auto">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-[2.5rem] blur-xl opacity-20 group-focus-within:opacity-40 transition-opacity"></div>
        <div className="relative flex items-center bg-white border-2 border-slate-100 rounded-[2rem] p-2 pr-6 shadow-xl shadow-blue-100/50 group-focus-within:border-blue-400 transition-all">
          <SearchIcon className="text-slate-300 mr-2 group-focus-within:text-blue-500 transition-colors" size={28} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder={t.search_ph}
            className="flex-1 p-4 text-xl outline-none bg-transparent font-medium text-slate-700 placeholder:text-slate-200"
          />
          <button
            onClick={handleSearch}
            disabled={loading}
            className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-lg shadow-blue-200 hover:scale-[1.02] transition-all active:scale-95 disabled:opacity-50 flex items-center gap-2"
          >
            {loading ? <Loader2 className="animate-spin" /> : t.search_button}
          </button>
        </div>
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 space-y-6">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-blue-100 rounded-full"></div>
            <div className="w-20 h-20 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
          </div>
          <p className="text-xl font-black text-blue-700 animate-pulse tracking-wide">{t.search_thinking}</p>
        </div>
      )}

      {result && !loading && (
        <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700 max-w-3xl mx-auto">
          <div className="p-10 border border-slate-100 rounded-[3rem] bg-white shadow-2xl shadow-blue-100/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-[5rem] -mr-10 -mt-10 opacity-50"></div>
            <div className="relative">
              <div className="flex items-center gap-3 mb-8 text-blue-700">
                <div className="p-2 bg-blue-50 rounded-xl">
                  <Sparkles size={24} />
                </div>
                <h3 className="text-2xl font-black tracking-tight">{t.search_summary}</h3>
              </div>
              <div className="prose prose-slate max-w-none leading-loose text-lg text-slate-700 whitespace-pre-wrap font-medium">
                {result.text}
              </div>
            </div>
          </div>

          {result.sources.length > 0 && (
            <div className="space-y-4">
              <h4 className="text-xl font-black text-slate-800 px-4 flex items-center gap-2">
                <div className="w-2 h-8 bg-blue-600 rounded-full"></div>
                {t.search_sources}
              </h4>
              <div className="grid gap-3">
                {result.sources.map((source, idx) => (
                  <a
                    key={idx}
                    href={source.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-5 bg-white border border-slate-100 rounded-2xl hover:border-blue-300 hover:shadow-lg hover:shadow-blue-50 transition-all group"
                  >
                    <div className="flex items-center gap-4 truncate ml-4">
                      <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                        <Globe size={18} />
                      </div>
                      <span className="font-bold text-slate-700 truncate">{source.title || source.uri}</span>
                    </div>
                    <ExternalLink size={20} className="text-slate-300 group-hover:text-blue-500 shrink-0 transition-colors" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
