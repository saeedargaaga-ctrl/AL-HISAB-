
import React, { useState } from 'react';
import { BookOpen, Plus, Sparkles, Image as ImageIcon, Book as BookIcon, ArrowRight, User as UserIcon, Loader2 } from 'lucide-react';
import { Book } from '../types';
import { generateBookCover } from '../services/gemini';

export const Library: React.FC<{ t: any, books: Book[], onAddBook: (book: Book) => void, onUpdateBook?: (book: Book) => void }> = ({ t, books, onAddBook, onUpdateBook }) => {
  const [view, setView] = useState<'list' | 'create' | 'read'>('list');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [newBook, setNewBook] = useState<Partial<Book>>({ title: '', author: '', content: '' });
  const [isGeneratingCover, setIsGeneratingCover] = useState(false);

  const handleCreateBook = () => {
    if (newBook.title && newBook.content) {
      const book: Book = {
        id: Date.now().toString(),
        title: newBook.title,
        author: newBook.author || 'Anonymous',
        content: newBook.content,
        coverImage: newBook.coverImage
      };
      onAddBook(book);
      setView('list');
      setNewBook({ title: '', author: '', content: '' });
    }
  };

  const handleGenerateCover = async () => {
    if (!newBook.title) return;
    setIsGeneratingCover(true);
    try {
      const cover = await generateBookCover(newBook.title, newBook.author || '', 'Modern Artistic');
      if (cover) setNewBook(prev => ({ ...prev, coverImage: cover }));
    } finally {
      setIsGeneratingCover(false);
    }
  };

  const handleUpdateExistingCover = async () => {
    if (!selectedBook || isGeneratingCover) return;
    setIsGeneratingCover(true);
    try {
      const cover = await generateBookCover(selectedBook.title, selectedBook.author, 'Elegent Professional');
      if (cover && onUpdateBook) {
        const updated = { ...selectedBook, coverImage: cover };
        onUpdateBook(updated);
        setSelectedBook(updated);
      }
    } finally {
      setIsGeneratingCover(false);
    }
  };

  if (view === 'read' && selectedBook) {
    return (
      <div className="max-w-4xl mx-auto py-6">
        <button onClick={() => setView('list')} className="mb-8 flex items-center gap-2 font-black text-rose-600 hover:text-rose-700 transition-colors bg-rose-50 px-6 py-2 rounded-full w-fit">
          <ArrowRight size={20} /> {t.back}
        </button>
        <div className="bg-white p-8 md:p-16 border border-rose-100 rounded-[3rem] min-h-[80vh] shadow-2xl shadow-rose-100/50 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-rose-50 rounded-bl-[10rem] -mr-32 -mt-32 opacity-30"></div>
          <div className="relative">
            <div className="flex flex-col md:flex-row gap-10 items-start mb-16">
              <div className="relative w-full md:w-64 aspect-[3/4] rounded-2xl overflow-hidden shadow-2xl shadow-rose-200 border-4 border-white rotate-2 group">
                {selectedBook.coverImage ? (
                  <img src={selectedBook.coverImage} className="w-full h-full object-cover" alt={selectedBook.title} />
                ) : (
                  <div className="w-full h-full bg-rose-100 flex items-center justify-center">
                    <BookIcon className="text-rose-300" size={80} />
                  </div>
                )}
                {isGeneratingCover && (
                  <div className="absolute inset-0 bg-white/80 flex items-center justify-center backdrop-blur-sm">
                    <Loader2 className="animate-spin text-rose-500" size={40} />
                  </div>
                )}
              </div>
              <div className="flex-1 space-y-4 pt-6">
                <h1 className="text-5xl font-black text-slate-800 tracking-tight leading-tight">{selectedBook.title}</h1>
                <p className="text-xl text-rose-500 font-bold flex items-center gap-2">
                  <div className="w-8 h-1 bg-rose-500 rounded-full"></div>
                  {t.lib_author_by} {selectedBook.author}
                </p>
                <button 
                  onClick={handleUpdateExistingCover}
                  disabled={isGeneratingCover}
                  className="flex items-center gap-2 px-6 py-3 bg-rose-500 text-white rounded-2xl font-bold shadow-lg shadow-rose-100 hover:bg-rose-600 disabled:opacity-50 transition"
                >
                  {isGeneratingCover ? <Loader2 className="animate-spin" size={20} /> : <Sparkles size={20} />}
                  {t.lib_ai_cover}
                </button>
              </div>
            </div>
            <div className="prose prose-xl prose-rose max-w-none leading-loose text-slate-700 whitespace-pre-wrap font-serif border-t border-slate-50 pt-12">
              {selectedBook.content}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'create') {
    return (
      <div className="max-w-5xl mx-auto space-y-12 pb-20">
        <div className="flex justify-between items-center">
          <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.lib_create_title}</h2>
          <button onClick={() => setView('list')} className="px-6 py-3 border-2 border-slate-100 rounded-2xl font-bold text-slate-500 hover:bg-slate-50 transition-colors">{t.cancel}</button>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          <div className="md:col-span-1 space-y-6">
            <div className="aspect-[3/4] border-4 border-white rounded-[2rem] overflow-hidden bg-rose-50 flex flex-col items-center justify-center relative shadow-2xl shadow-rose-100 group">
              {newBook.coverImage ? (
                <img src={newBook.coverImage} className="w-full h-full object-cover" alt="Cover" />
              ) : (
                <div className="text-center p-8">
                  <ImageIcon size={64} className="text-rose-200 mx-auto mb-4" />
                </div>
              )}
              {isGeneratingCover && (
                <div className="absolute inset-0 bg-white/80 flex items-center justify-center backdrop-blur-sm">
                  <div className="w-12 h-12 border-4 border-rose-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
            <button 
              onClick={handleGenerateCover}
              disabled={!newBook.title || isGeneratingCover}
              className="w-full flex items-center justify-center gap-3 p-5 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-[1.5rem] font-black shadow-xl shadow-rose-100 hover:scale-[1.02] transition-all disabled:opacity-50 active:scale-95"
            >
              <Sparkles size={24} /> {t.lib_ai_cover}
            </button>
          </div>

          <div className="md:col-span-2 space-y-8 bg-white p-8 md:p-12 border border-slate-50 rounded-[3rem] shadow-xl shadow-slate-100">
            <input 
              placeholder={t.lib_title_ph}
              value={newBook.title}
              onChange={e => setNewBook({...newBook, title: e.target.value})}
              className="w-full text-3xl font-black p-4 border-b-4 border-rose-100 outline-none focus:border-rose-500 transition-colors bg-transparent text-slate-800"
            />
            <input 
              placeholder={t.lib_author_ph}
              value={newBook.author}
              onChange={e => setNewBook({...newBook, author: e.target.value})}
              className="w-full p-4 text-xl font-bold border-b-2 border-slate-50 outline-none focus:border-rose-300 transition-colors bg-transparent text-slate-600"
            />
            <textarea 
              placeholder={t.lib_content_ph}
              value={newBook.content}
              onChange={e => setNewBook({...newBook, content: e.target.value})}
              className="w-full h-80 p-6 border-2 border-slate-50 rounded-[2rem] outline-none focus:border-rose-200 transition-all resize-none text-lg leading-loose font-serif text-slate-700 bg-slate-50/50"
            />
            <button 
              onClick={handleCreateBook}
              className="w-full py-5 bg-slate-900 text-white rounded-[1.5rem] font-black text-xl hover:bg-slate-800 shadow-2xl shadow-slate-200 transition-all active:scale-95"
            >
              {t.lib_publish}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-right">
          <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t.lib_title}</h2>
          <p className="text-lg text-slate-500 font-medium">{t.lib_desc}</p>
        </div>
        <button 
          onClick={() => setView('create')}
          className="flex items-center gap-3 bg-gradient-to-r from-rose-500 to-pink-600 text-white px-10 py-5 rounded-[2rem] font-black text-lg shadow-2xl shadow-rose-200 hover:scale-[1.05] transition-all active:scale-95"
        >
          <Plus size={28} /> {t.lib_new}
        </button>
      </div>

      {books.length === 0 ? (
        <div className="py-32 text-center space-y-6 border-4 border-dashed border-rose-50 rounded-[4rem] bg-rose-50/20">
          <BookOpen size={64} className="mx-auto text-rose-200" />
          <p className="text-2xl font-black text-rose-300">{t.lib_empty}</p>
          <button onClick={() => setView('create')} className="px-8 py-3 bg-rose-600 text-white rounded-2xl font-black">{t.lib_first}</button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10">
          {books.map(book => (
            <div key={book.id} onClick={() => { setSelectedBook(book); setView('read'); }} className="group cursor-pointer">
              <div className="aspect-[3/4] border-4 border-white rounded-[2rem] overflow-hidden shadow-xl bg-white relative group-hover:shadow-rose-200 transition-all">
                {book.coverImage ? <img src={book.coverImage} className="w-full h-full object-cover" /> : <BookIcon className="m-auto text-rose-100" size={60} />}
                <div className="absolute inset-0 bg-rose-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h4 className="mt-4 font-black text-slate-800 truncate">{book.title}</h4>
              <p className="text-sm font-bold text-rose-400 truncate">{book.author}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
