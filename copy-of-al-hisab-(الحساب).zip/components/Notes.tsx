
import React, { useState } from 'react';
import { Plus, Save, Trash2, Wand2, CheckCircle, FileText, ChevronRight } from 'lucide-react';
import { Note, Language } from '../types';
import { optimizeText } from '../services/gemini';

export const Notes: React.FC<{ t: any, notes: Note[], language: Language, onSave: (note: Note) => void, onDelete: (id: string) => void }> = ({ t, notes, language, onSave, onDelete }) => {
  const [activeNote, setActiveNote] = useState<Partial<Note> | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [showToast, setShowToast] = useState(false);

  const handleSave = () => {
    if (activeNote?.content) {
      onSave({
        id: activeNote.id || Date.now().toString(),
        title: activeNote.title || t.notes_new,
        content: activeNote.content,
        createdAt: activeNote.createdAt || Date.now()
      });
      setActiveNote(null);
      setShowToast(true);
      setTimeout(() => setShowToast(false), 2000);
    }
  };

  const handleAIImprove = async () => {
    if (activeNote?.content) {
      setIsOptimizing(true);
      try {
        const improved = await optimizeText(activeNote.content, language);
        setActiveNote(prev => ({ ...prev, content: improved }));
      } finally {
        setIsOptimizing(false);
      }
    }
  };

  return (
    <div className="h-full flex flex-col md:flex-row gap-8 p-4">
      {/* Sidebar */}
      <div className="w-full md:w-72 space-y-6">
        <button 
          onClick={() => setActiveNote({ title: '', content: '' })}
          className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-amber-400 to-orange-500 text-white p-5 rounded-[1.5rem] font-black text-lg shadow-xl shadow-orange-100 hover:scale-[1.02] transition active:scale-95"
        >
          <Plus size={24} /> {t.notes_new}
        </button>
        <div className="space-y-3 overflow-y-auto max-h-[60vh] custom-scrollbar pr-2">
          {notes.map(note => (
            <div 
              key={note.id} 
              onClick={() => setActiveNote(note)}
              className={`p-4 bg-white border-2 rounded-2xl cursor-pointer hover:border-amber-400 transition-all group relative overflow-hidden ${activeNote?.id === note.id ? 'border-amber-400 shadow-lg shadow-amber-50 ring-2 ring-amber-100' : 'border-slate-100 shadow-sm'}`}
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-amber-50 text-amber-500 rounded-lg flex items-center justify-center shrink-0">
                    <FileText size={18} />
                  </div>
                  <h4 className="font-bold text-slate-800 truncate pr-2">{note.title}</h4>
                </div>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(note.id); }} 
                  className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-500 transition-opacity p-1"
                >
                  <Trash2 size={16} />
                </button>
              </div>
              <p className="text-xs text-slate-400 font-bold mt-3 px-1">{new Date(note.createdAt).toLocaleDateString()}</p>
            </div>
          ))}
          {notes.length === 0 && (
            <div className="text-center py-10 opacity-30">
              <FileText size={40} className="mx-auto mb-2" />
              <p className="text-sm font-bold">{t.notes_empty}</p>
            </div>
          )}
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 flex flex-col bg-white border border-slate-100 rounded-[2.5rem] overflow-hidden shadow-2xl shadow-slate-200/50 min-h-[600px]">
        {activeNote ? (
          <>
            <div className="flex items-center gap-4 p-6 border-b border-slate-50">
              <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center shrink-0">
                <FileText size={24} />
              </div>
              <input 
                value={activeNote.title}
                onChange={e => setActiveNote({...activeNote, title: e.target.value})}
                placeholder={t.notes_title_ph}
                className="text-2xl font-black text-slate-800 outline-none w-full bg-transparent placeholder:text-slate-300"
              />
            </div>
            <textarea 
              value={activeNote.content}
              onChange={e => setActiveNote({...activeNote, content: e.target.value})}
              placeholder={t.notes_content_ph}
              className="flex-1 p-8 resize-none outline-none text-lg leading-relaxed text-slate-700 bg-transparent placeholder:text-slate-200"
            />
            <div className="p-6 border-t border-slate-50 flex flex-wrap justify-between items-center gap-4 bg-slate-50/30">
              <button 
                onClick={handleAIImprove}
                disabled={isOptimizing}
                className={`flex items-center gap-3 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-100 transition-all hover:bg-indigo-700 disabled:opacity-50 ${isOptimizing ? 'animate-pulse' : ''}`}
              >
                {isOptimizing ? t.loading : <><Wand2 size={20} /> {t.notes_ai_improve}</>}
              </button>
              <div className="flex gap-3">
                <button 
                  onClick={() => setActiveNote(null)}
                  className="px-6 py-3 border border-slate-200 text-slate-500 rounded-2xl font-bold hover:bg-slate-50 transition-colors"
                >
                  {t.cancel}
                </button>
                <button 
                  onClick={handleSave}
                  className="flex items-center gap-2 px-8 py-3 bg-amber-500 text-white rounded-2xl font-black shadow-lg shadow-amber-100 hover:bg-amber-600 active:scale-95 transition-all"
                >
                  <Save size={20} /> {t.save}
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center bg-gradient-to-b from-white to-slate-50">
            <div className="w-24 h-24 bg-amber-50 text-amber-500 rounded-[2rem] flex items-center justify-center mb-6 shadow-xl shadow-amber-50/50">
              <Plus size={48} />
            </div>
            <h3 className="text-2xl font-black text-slate-800 mb-2">{t.notes_new}</h3>
            <p className="text-slate-400 max-w-sm font-medium">{t.notes_empty}</p>
          </div>
        )}
      </div>

      {showToast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-8 py-4 rounded-3xl flex items-center gap-3 shadow-2xl shadow-indigo-200 animate-in fade-in slide-in-from-bottom-4">
          <CheckCircle className="text-emerald-400" size={24} /> 
          <span className="font-bold">{t.notes_saved}</span>
        </div>
      )}
    </div>
  );
};
