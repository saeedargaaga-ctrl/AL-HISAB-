
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Zap, Sparkles } from 'lucide-react';

export const Clock: React.FC<{ t: any }> = ({ t }) => {
  const [time, setTime] = useState(new Date());
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isFocusMode, setIsFocusMode] = useState(false);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimerSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning]);

  const formatTimer = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const locale = document.documentElement.lang === 'ar' ? 'ar-EG' : 'en-US';

  return (
    <div className="flex flex-col items-center justify-center space-y-12 py-10 animate-fade-in">
      <div className="text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-400 uppercase tracking-widest">{t.clock_now}</h2>
        <div className="text-8xl font-black tracking-tighter text-slate-800 tabular-nums transition-all duration-500 hover:scale-110">
          {time.toLocaleTimeString(locale, { hour12: false })}
        </div>
      </div>

      <div className={`p-10 rounded-[3rem] w-full max-w-md transition-all duration-700 shadow-2xl ${isFocusMode ? 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-emerald-200' : 'bg-white text-slate-800 shadow-slate-200'}`}>
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl transition-all duration-500 ${isFocusMode ? 'bg-white/20 scale-110 rotate-12' : 'bg-emerald-50 text-emerald-600'}`}>
              <Zap size={24} />
            </div>
            <h3 className="text-2xl font-black">{t.clock_focus}</h3>
          </div>
          <button 
            onClick={() => setIsFocusMode(!isFocusMode)}
            className={`p-3 rounded-2xl transition-all hover-lift active-scale ${isFocusMode ? 'bg-white text-emerald-700' : 'bg-emerald-600 text-white shadow-lg shadow-emerald-200'}`}
          >
            {isFocusMode ? <Sparkles size={20} /> : <Zap size={20} />}
          </button>
        </div>

        <div className="text-7xl font-black text-center mb-10 tabular-nums font-mono tracking-tight transition-transform duration-300">
          {formatTimer(timerSeconds)}
        </div>

        <div className="flex justify-center gap-4">
          <button 
            onClick={() => setIsRunning(!isRunning)}
            className={`flex-1 flex items-center justify-center gap-3 py-4 rounded-2xl font-bold text-lg transition-all shadow-lg active-scale hover-lift ${isFocusMode ? 'bg-white text-emerald-700 hover:bg-emerald-50' : 'bg-slate-900 text-white hover:bg-slate-800 shadow-slate-200'}`}
          >
            {isRunning ? <><Pause size={24} /> {t.clock_stop}</> : <><Play size={24} /> {t.clock_start}</>}
          </button>
          <button 
            onClick={() => { setTimerSeconds(0); setIsRunning(false); }}
            className={`p-4 rounded-2xl font-bold transition-all border-2 hover-lift active-scale ${isFocusMode ? 'border-white/20 hover:bg-white/10 text-white' : 'border-slate-100 bg-slate-50 text-slate-500 hover:bg-slate-100'}`}
          >
            <RotateCcw size={24} />
          </button>
        </div>
        
        {isRunning && (
          <div className={`flex items-center justify-center gap-2 mt-8 py-2 rounded-full font-bold text-sm animate-pulse ${isFocusMode ? 'bg-white/10 text-emerald-100' : 'text-emerald-600'}`}>
            <Sparkles size={16} /> {t.clock_success}
          </div>
        )}
      </div>
    </div>
  );
};
