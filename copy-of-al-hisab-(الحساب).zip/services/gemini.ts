
import { GoogleGenAI, Type } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const optimizeText = async (text: string, language: string = 'ar') => {
  const ai = getAI();
  const langMap: Record<string, string> = {
    ar: 'Arabic',
    en: 'English',
    ur: 'Urdu',
    ru: 'Russian',
    zh: 'Chinese'
  };
  const targetLang = langMap[language] || 'Arabic';
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Improve and organize this text professionally while maintaining its meaning. Ensure the output is in ${targetLang}:\n\n${text}`,
  });
  return response.text;
};

export const chatWithAI = async (message: string, language: string = 'ar', history: any[] = []) => {
  const ai = getAI();
  const langMap: Record<string, string> = {
    ar: 'Arabic',
    en: 'English',
    ur: 'Urdu',
    ru: 'Russian',
    zh: 'Chinese'
  };
  const targetLang = langMap[language] || 'Arabic';

  // Prepare history for generateContent
  const contents = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.text }]
  }));
  contents.push({ role: 'user', parts: [{ text: message }] });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: contents,
    config: {
      systemInstruction: `You are an intelligent assistant in the "Al-Hisab" (الحساب) application. You assist users with studies, organization, research, and innovation. Your responses must be accurate, inspiring, and strictly in the ${targetLang} language.`, 
    }
  });
  return response.text;
};

export const summarizeSearch = async (query: string, language: string = 'ar') => {
  const ai = getAI();
  const langMap: Record<string, string> = {
    ar: 'Arabic',
    en: 'English',
    ur: 'Urdu',
    ru: 'Russian',
    zh: 'Chinese'
  };
  const targetLang = langMap[language] || 'Arabic';

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Search for and explain this topic with depth and simplicity. Respond only in ${targetLang}: ${query}`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(chunk => ({
    uri: chunk.web?.uri,
    title: chunk.web?.title
  })).filter(s => s.uri) || [];

  return {
    text: response.text,
    sources: sources
  };
};

export const generateImage = async (prompt: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [{ text: `High quality artistic style: ${prompt}` }] },
    config: {
      imageConfig: { aspectRatio: "16:9" }
    }
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  }
  return null;
};

export const generateVideo = async (prompt: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: `Cinematic artistic style: ${prompt}`,
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: '16:9'
    }
  });

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await videoResponse.blob();
  return URL.createObjectURL(blob);
};

export const generateBookCover = async (title: string, author: string, style: string) => {
  const ai = getAI();
  const prompt = `Professional book cover for "${title}" by "${author}". Style: ${style}. Artistic, elegant, high contrast.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [{ text: prompt }] },
    config: {
      imageConfig: { aspectRatio: "3:4" }
    }
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  }
  return null;
};

export const evaluateIdea = async (title: string, desc: string, language: string = 'ar') => {
  const ai = getAI();
  const langMap: Record<string, string> = {
    ar: 'Arabic',
    en: 'English',
    ur: 'Urdu',
    ru: 'Russian',
    zh: 'Chinese'
  };
  const targetLang = langMap[language] || 'Arabic';

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Evaluate this innovative idea and provide suggestions for improvement. Respond in ${targetLang}:\nTitle: ${title}\nDescription: ${desc}`,
  });
  return response.text;
};
